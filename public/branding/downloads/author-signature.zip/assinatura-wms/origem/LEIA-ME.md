# Assinaturas de Gabriel Lourenço

Nove marcas pessoais para diferentes contextos de desenvolvimento. O Monograma GL (01) é a assinatura adotada no portfólio.

| Nº | Marca | Contexto |
| --- | --- | --- |
| 01 | Monograma GL | Portfólio e projetos profissionais |
| 02 | Code GL | APIs, ferramentas e documentação |
| 05 | Conexão | Dados, integrações e automação |
| 07 | Level GL | Aprendizado e gamificação |
| 08 | Checkpoint | Desafios e ferramentas |
| 09 | Rota Livre | Exploração e projetos autorais |
| 10 | Faixa Vermelha | Projetos pessoais e aventura |
| 11 | Alvinegro GL | Projetos pessoais e esporte |
| 12 | Vila Dev | Desenvolvimento, esporte e jogos |

## Arquivos

- `icons/`: ícones em SVG, com viewBox de 64 × 64.
- `signatures/`: assinaturas em SVG, com viewBox de 260 × 56, em português (`pt`) e inglês (`en`).
- `png/`: ícones transparentes de 512 × 512 pixels.
- `catalogo.json`: nomes, conceitos, paletas e sugestões de uso.

Cada marca possui versões para fundos claros (`light`) e escuros (`dark`). Os arquivos com sufixo `-mono` são monocromáticos. Todos os ícones e assinaturas têm fundo transparente.

Os números originais foram preservados. A coleção contém apenas 01, 02, 05, 07, 08, 09, 10, 11 e 12.

## Uso

Escolha a marca de acordo com o contexto do projeto e a variante de acordo com o fundo. Prefira SVG em interfaces: o formato pode ser redimensionado sem perder definição. Preserve a proporção e use a variante monocromática quando a composição pedir uma única cor.

Exemplo de assinatura em um projeto com fundo claro:

```html
<img
    src="/assets/branding/signatures/01-monograma-gl-pt-light.svg"
    width="260"
    height="56"
    alt="Desenvolvido por Gabriel Lourenço"
>
```
