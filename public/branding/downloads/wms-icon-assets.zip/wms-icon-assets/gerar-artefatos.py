#!/usr/bin/env python3
"""Prepara fontes vetoriais, exporta PNGs e empacota a entrega da etapa 2.

Executar: python3 docs-gerais/identidade-visual/icone/gerar-artefatos.py
Requer Python 3.10+, Node e Playwright/Chromium do submódulo web instalados.
"""
import hashlib
import json
from pathlib import Path
import struct
import subprocess
import xml.etree.ElementTree as ET
import zipfile

ROOT = Path(__file__).resolve().parent
GEOMETRY = json.loads((ROOT / 'geometria.json').read_text())
TOKENS = json.loads((ROOT.parent / 'tokens.json').read_text())
COLORS = TOKENS['color']['brand']
PATH = GEOMETRY['path']
JOBS = []


def write(name, text):
    target = ROOT / name
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_text(text, encoding='utf-8')


def write_json(name, data):
    write(name, json.dumps(data, indent=2, ensure_ascii=False) + '\n')


def symbol(color, transform=None):
    mark = f'<path fill="{color}" d="{PATH}"/>'
    return f'<g transform="{transform}">{mark}</g>' if transform else mark


def svg(name, content, size=128):
    write(name, f'<svg xmlns="http://www.w3.org/2000/svg" width="{size}" height="{size}" viewBox="0 0 {size} {size}" role="img" aria-labelledby="title">\n'
          f'  <title id="title">WMS SaaS — W de percurso</title>\n  {content}\n</svg>\n')


def job(source, size, output, transparent=False):
    JOBS.append(dict(source=source, size=size, output=output, transparent=transparent))


def android_vector(color):
    a = GEOMETRY['android']
    return ('<?xml version="1.0" encoding="utf-8"?>\n'
            '<vector xmlns:android="http://schemas.android.com/apk/res/android" android:width="108dp" android:height="108dp" android:viewportWidth="108" android:viewportHeight="108">\n'
            f'  <group android:scaleX="{a["scale"]}" android:scaleY="{a["scale"]}" android:translateX="{a["translate"]}" android:translateY="{a["translate"]}">\n'
            f'    <path android:fillColor="{color}" android:pathData="{PATH}"/>\n  </group>\n</vector>\n')


def generate():
    for variant, color in [('green', COLORS['primary']), ('lime', COLORS['accent']), ('dark', COLORS['ink']), ('white', '#FFFFFF')]:
        svg(f'svg/symbol-{variant}.svg', symbol(color))
        for size in [32, 128, 512]:
            job(f'svg/symbol-{variant}.svg', size, f'png/symbol-{variant}-{size}.png', True)

    background = f'<rect width="128" height="128" fill="{COLORS["ink"]}"/>'
    svg('svg/app-icon.svg', background + symbol(COLORS['accent']))
    svg('svg/favicon.svg', f'<rect width="128" height="128" rx="24" fill="{COLORS["ink"]}"/>' + symbol(COLORS['accent']))
    m = GEOMETRY['maskable']
    svg('svg/maskable.svg', background + symbol(COLORS['accent'], f'translate({m["translate"]} {m["translate"]}) scale({m["scale"]})'))
    for size in [16, 32, 48]:
        job('svg/favicon.svg', size, f'web/favicon-{size}.png', True)
    job('svg/app-icon.svg', 180, 'web/apple-touch-icon.png')
    for size in [192, 512]:
        job('svg/app-icon.svg', size, f'web/icon-{size}.png')
        job('svg/maskable.svg', size, f'web/icon-maskable-{size}.png')
    job('svg/app-icon.svg', 1024, 'png/app-icon-1024.png')

    # Referência de recursos de imagem; não instala PWA nem define rotas/sessão.
    write_json('web/icons-manifest.json', {'icons': [
        {'src': f'icon-{size}.png', 'sizes': f'{size}x{size}', 'type': 'image/png', 'purpose': 'any'} for size in [192, 512]
    ] + [
        {'src': f'icon-maskable-{size}.png', 'sizes': f'{size}x{size}', 'type': 'image/png', 'purpose': 'maskable'} for size in [192, 512]
    ]})

    a = GEOMETRY['android']
    transform = f'translate({a["translate"]} {a["translate"]}) scale({a["scale"]})'
    svg('svg/android-foreground.svg', symbol(COLORS['accent'], transform), 108)
    svg('svg/android-monochrome.svg', symbol('#FFFFFF', transform), 108)
    svg('svg/android-themed-preview.svg', symbol(COLORS['ink'], transform), 108)
    svg('svg/android-composite.svg', f'<rect width="108" height="108" fill="{COLORS["ink"]}"/>' + symbol(COLORS['accent'], transform), 108)
    svg('svg/android-background.svg', f'<rect width="108" height="108" fill="{COLORS["ink"]}"/>', 108)
    job('svg/android-foreground.svg', 432, 'android/layers/foreground-432.png', True)
    job('svg/android-monochrome.svg', 432, 'android/layers/monochrome-432.png', True)
    job('svg/android-background.svg', 432, 'android/layers/background-432.png')
    for density, size in [('mdpi', 48), ('hdpi', 72), ('xhdpi', 96), ('xxhdpi', 144), ('xxxhdpi', 192)]:
        job('svg/app-icon.svg', size, f'android/res/mipmap-{density}/ic_launcher.png')
    write('android/res/drawable/ic_launcher_foreground.xml', android_vector(COLORS['accent']))
    write('android/res/drawable/ic_launcher_monochrome.xml', android_vector('#FFFFFF'))
    write('android/res/values/wms_launcher_colors.xml', '<?xml version="1.0" encoding="utf-8"?>\n<resources>\n'
          f'  <color name="wms_launcher_background">{COLORS["ink"]}</color>\n</resources>\n')
    for version in [26, 33]:
        mono = '  <monochrome android:drawable="@drawable/ic_launcher_monochrome"/>\n' if version == 33 else ''
        write(f'android/res/mipmap-anydpi-v{version}/ic_launcher.xml', '<?xml version="1.0" encoding="utf-8"?>\n'
              '<adaptive-icon xmlns:android="http://schemas.android.com/apk/res/android">\n'
              '  <background android:drawable="@color/wms_launcher_background"/>\n'
              '  <foreground android:drawable="@drawable/ic_launcher_foreground"/>\n' + mono + '</adaptive-icon>\n')

    # Correspondem ao catálogo iPhone/iPad já existente no projeto Flutter.
    ios = []
    for idiom, entries in [
        ('iphone', [(20, [2, 3]), (29, [1, 2, 3]), (40, [2, 3]), (60, [2, 3])]),
        ('ipad', [(20, [1, 2]), (29, [1, 2]), (40, [1, 2]), (76, [1, 2]), (83.5, [2])]),
        ('ios-marketing', [(1024, [1])]),
    ]:
        for points, scales in entries:
            for scale in scales:
                filename = f'Icon-App-{points}x{points}@{scale}x.png'
                ios.append({'size': f'{points}x{points}', 'idiom': idiom, 'filename': filename, 'scale': f'{scale}x'})
                output = f'ios/AppIcon.appiconset/{filename}'
                if not any(j['output'] == output for j in JOBS):
                    job('svg/app-icon.svg', int(points * scale), output)
    write_json('ios/AppIcon.appiconset/Contents.json', {'images': ios, 'info': {'version': 1, 'author': 'xcode'}})
    write_json('exportacoes.json', JOBS)


def package():
    for j in JOBS:
        data = (ROOT / j['output']).read_bytes()
        assert data[:8] == b'\x89PNG\r\n\x1a\n', j['output']
        width, height, depth, color_type, _, _, _ = struct.unpack('>IIBBBBB', data[16:29])
        assert (width, height, depth) == (j['size'], j['size'], 8), j['output']
        if not j['transparent']:
            assert color_type == 2, f'{j["output"]}: precisa ser RGB sem canal alpha'
    # ICO com três entradas PNG nativas, sem redimensionar bitmaps.
    layers = [(size, (ROOT / f'web/favicon-{size}.png').read_bytes()) for size in [16, 32, 48]]
    header = struct.pack('<HHH', 0, 1, len(layers))
    directory, payload, offset = b'', b'', 6 + 16 * len(layers)
    for size, data in layers:
        directory += struct.pack('<BBBBHHII', size, size, 0, 0, 1, 32, len(data), offset)
        payload += data
        offset += len(data)
    (ROOT / 'web/favicon.ico').write_bytes(header + directory + payload)
    files = sorted(f for f in ROOT.rglob('*') if f.is_file() and f.suffix != '.zip' and f.name != 'manifesto.json')
    inventory = []
    for f in files:
        data = f.read_bytes()
        entry = {'path': str(f.relative_to(ROOT)), 'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()}
        if f.suffix == '.png':
            width, height, _, color_type, _, _, _ = struct.unpack('>IIBBBBB', data[16:29])
            entry.update(width=width, height=height, colorMode='RGB' if color_type == 2 else 'RGBA')
        if f.suffix == '.svg':
            entry['viewBox'] = ET.fromstring(data).get('viewBox')
        if f.suffix == '.ico':
            entry['sizes'] = [16, 32, 48]
        inventory.append(entry)
    write_json('manifesto.json', {
        'project': 'WMS SaaS', 'stage': '2/5', 'version': GEOMETRY['version'],
        'symbol': GEOMETRY['name'], 'author': 'Projeto de Gabriel Lourenço',
        'note': 'Recursos preparados nesta etapa. Integração web/mobile pendente para as etapas 4 e 5.',
        'files': inventory,
    })
    with zipfile.ZipFile(ROOT / 'wms-icon-assets.zip', 'w', zipfile.ZIP_DEFLATED) as archive:
        for f in sorted(ROOT.rglob('*')):
            if f.is_file() and f.suffix != '.zip':
                info = zipfile.ZipInfo('wms-icon-assets/' + str(f.relative_to(ROOT)), (2026, 10, 16, 0, 0, 0))
                info.compress_type = zipfile.ZIP_DEFLATED
                info.external_attr = 0o644 << 16
                archive.writestr(info, f.read_bytes())
    print(f'{len(JOBS)} PNGs validados, favicon.ico e pacote ZIP gerados.')


if __name__ == '__main__':
    generate()
    subprocess.run(['node', str(ROOT / 'renderizar.mjs')], check=True)
    package()
