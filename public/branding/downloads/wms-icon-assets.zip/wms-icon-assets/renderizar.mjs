// Rasteriza os SVGs originais com o Chromium já disponível no ambiente do web.
// Não altera fontes, arquivos ou dependências dos submódulos.
import fs from 'node:fs/promises';
import path from 'node:path';
import { fileURLToPath, pathToFileURL } from 'node:url';

const root = path.dirname(fileURLToPath(import.meta.url));
const packageFile = path.resolve(root, '../../../wms-saas-web/node_modules/playwright/index.mjs');
const { chromium } = await import(pathToFileURL(packageFile).href);
const jobs = JSON.parse(await fs.readFile(path.join(root, 'exportacoes.json'), 'utf8'));
const browser = await chromium.launch({
  headless: true,
  ...(process.env.PLAYWRIGHT_CHROMIUM_EXECUTABLE ? { executablePath: process.env.PLAYWRIGHT_CHROMIUM_EXECUTABLE } : {}),
  args: ['--no-sandbox'],
});
try {
  const page = await browser.newPage({ deviceScaleFactor: 1 });
  const cache = new Map();
  for (const job of jobs) {
    const key = `${job.source}:${job.size}:${job.transparent}`;
    let png = cache.get(key);
    if (!png) {
      const source = await fs.readFile(path.join(root, job.source), 'utf8');
      const svg = source.replace(/width="\d+" height="\d+"/, `width="${job.size}" height="${job.size}"`);
      await page.setViewportSize({ width: job.size, height: job.size });
      await page.setContent(`<style>html,body{margin:0;padding:0;width:100%;height:100%;background:transparent}svg{display:block}</style>${svg}`);
      png = await page.screenshot({ omitBackground: job.transparent });
      cache.set(key, png);
    }
    const destination = path.join(root, job.output);
    await fs.mkdir(path.dirname(destination), { recursive: true });
    await fs.writeFile(destination, png);
  }
  console.log(`${jobs.length} PNGs exportados a partir de ${cache.size} renderizações vetoriais.`);
} finally {
  await browser.close();
}
